# Master version for Pillow
__version__ = "8.3.1"
